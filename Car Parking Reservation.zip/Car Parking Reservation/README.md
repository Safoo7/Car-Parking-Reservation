# Parking-Lot
Simple Project that simulate a little parking lot using ES6 Javascript and manipulate LocalStorage!
